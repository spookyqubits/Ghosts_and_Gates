import React from 'react';
import ReactDomClient from 'react-dom/client';

import AppStateHOC from '../lib/app-state-hoc.jsx';
import GUI from '../containers/gui.jsx';

const Editor = AppStateHOC(GUI);

const starters = new Map([
    ['cat', ['schrodingers-cat', 'Schrödinger’s Cat Decay Lab']],
    ['phase', ['phase-arcade', 'Phase Arcade']],
    ['slits', ['photon-studio', 'Photon Studio']],
    ['bell', ['bell-pair-lab', 'Bell Pair Lab']],
    ['teleport', ['teleportation-lab', 'Teleportation Lab']]
]);

const returnToGhostBlocks = () => {
    window.location.assign('../');
};

export default appTarget => {
    GUI.setAppElement(appTarget);
    const starterKey = new URLSearchParams(window.location.search).get('starter');
    const starter = starters.get(starterKey);

    if (process.env.NODE_ENV === 'production') {
        window.onbeforeunload = () => true;
    }

    const root = ReactDomClient.createRoot(appTarget);
    root.render(
        <Editor
            canEditTitle
            canSave={false}
            onClickLogo={returnToGhostBlocks}
            projectHost={new URL('../projects', window.location.href).href}
            projectId={starter ? `${starter[0]}.sb3` : '0'}
            projectTitle={starter ? starter[1] : 'Ghost Blocks Project'}
        />
    );
};
