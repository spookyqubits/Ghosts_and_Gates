import React from 'react';
import ReactDomClient from 'react-dom/client';

import AppStateHOC from '../lib/app-state-hoc.jsx';
import GUI from '../containers/gui.jsx';

const Editor = AppStateHOC(GUI);

const returnToGhostBlocks = () => {
    window.location.assign('../');
};

export default appTarget => {
    GUI.setAppElement(appTarget);
    const useCatStarter = new URLSearchParams(window.location.search).get('starter') === 'cat';

    if (process.env.NODE_ENV === 'production') {
        window.onbeforeunload = () => true;
    }

    const root = ReactDomClient.createRoot(appTarget);
    root.render(
        <Editor
            canEditTitle
            canSave={false}
            onClickLogo={returnToGhostBlocks}
            projectHost={new URL('../projects', window.location.href).href}
            projectId={useCatStarter ? 'schrodingers-cat.sb3' : '0'}
            projectTitle={useCatStarter ? 'Schrödinger’s Cat' : 'Ghost Blocks Project'}
        />
    );
};
